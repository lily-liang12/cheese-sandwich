# Themes

Beautiful themes are much appreciated. If you want to submit one, clone the repo, add theme to rc/themes directory, and submit pull request with it.
