Only **code quality** does matter.

Everything else is up to your personal taste. 

However this doesn't mean that we will be tolerant to any kind of antics
