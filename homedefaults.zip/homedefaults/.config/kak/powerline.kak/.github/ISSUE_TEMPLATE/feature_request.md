---
name: Feature request
about: Suggest an idea for this project

---

<!-- If you requesting a feature please prepend "[Feature Request]" to issue name -->
<!-- Describe what do you like to have in powerline.kak. If possible propose a way how it could be implemented -->
